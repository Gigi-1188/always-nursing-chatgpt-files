"use client";
import BrandLogo from "../BrandLogo";
import DashboardSwitch from "./DashboardSwitch";
import DemoLinks from "./DemoLinks";
import BrandColors from "./BrandColors";
import NoCallNoShow,{AbsenceNotice} from "../no-call-no-show/NoCallNoShow";
import InactiveBoard from "./inactive/InactiveBoard";
import MerchPortal from "../merch/MerchPortal";
import {useState} from "react";
import ContractAgreement from "../facility-contract/ContractAgreement";
import EvaluationIncentive,{IncentiveNotice} from "../incentives/EvaluationIncentive";
import QuarterlyContest,{ContestAnnouncer} from "../contest/QuarterlyContest";
import FeedbackWorkspace,{FeedbackNotice} from "../facility-feedback/FeedbackWorkspace";
import Expansion from "../Expansion";
import ApplicantRecords from "./ApplicantRecords";
import StaffingWorkspace from "../workspace/StaffingWorkspace";
import TrainingVideos from '../training/TrainingVideos';
import ReferralProgram,{ReferralNotice} from '../referrals/ReferralProgram';
import EmployeeHome from "../home/EmployeeHome";
import FacilitiesHome from "../facilities/FacilitiesHome";
export const agencyTabs=['Home','Facility Home','Overview','Message and Files','Applications and Credentials','Shifts and Checklist','Clock-In and Breaks','Evaluations and Incentives','Attendance & DNR','Inactive Board','Branding & Connections','Contracts','Training Videos'];
export default function OfficeDashboard(){
 const [view,setView]=useState('Home'),[sub,setSub]=useState(''),[contestEmployee,setContestEmployee]=useState('');
 function open(title:string,detail=''){setView(title);setSub(detail)}
 const groups:Record<string,string[]>={'Applications and Credentials':['Applications','Credential Approval'],'Evaluations and Incentives':['Evaluation Incentive','Quarterly Excellence Contest','Referral Program'],'Attendance & DNR':['Facility Evaluations & DNR','No Call, No Show'],'Branding & Connections':['Connections','Brand Images','Brand Colors','Always Nursing Merch','Demo Access Links']};
 const selected=sub||groups[view]?.[0];
 return <div className="shell"><aside className="rail"><div className="brand"><BrandLogo/><div><strong>always nursing</strong><small>STAFFING AGENCY</small></div></div><nav aria-label="Agency Dashboard Sections">{agencyTabs.map(t=><button className={view===t?'nav-active':''} key={t} onClick={()=>open(t)}>{t}</button>)}<a href="/employee">Employee Dashboard</a><a href="/office/demo">Learning & Demo</a></nav><p className="rail-foot">Office Access<br/><small>Always Nursing Operations</small></p></aside><main className="content"><DashboardSwitch active="staffing"/><header><div><small className="eyebrow">ALWAYS NURSING · OFFICE</small><h1>Staffing Dashboard</h1></div><div className="avatar">AN</div></header><div className="banner">Messages, uploaded files, direct shift postings, and attendance records are saved. OnShift, license verification vendors, and payroll providers are not connected. No patient information should be entered.</div><ContestAnnouncer/><AbsenceNotice office onOpen={()=>open('Attendance & DNR','No Call, No Show')}/><FeedbackNotice onOpen={()=>open('Attendance & DNR')}/><IncentiveNotice onOpen={()=>open('Evaluations and Incentives')}/><ReferralNotice onOpen={()=>open('Evaluations and Incentives','Referral Program')}/>{groups[view]&&<div className="tabs" aria-label={view}>{groups[view].map(t=><button key={t} className={selected===t?'on':''} onClick={()=>setSub(t)}>{t}</button>)}</div>}
 {view==='Home'?<EmployeeHome office onApplication={()=>open('Applications and Credentials')} onShifts={()=>open('Shifts and Checklist')} onFacilities={()=>open('Facility Home')}/>:view==='Facility Home'?<FacilitiesHome office onEmployee={()=>open('Home')}/>:view==='Training Videos'?<><TrainingVideos/><EmployeeHome office trainingOnly onApplication={()=>open('Applications and Credentials')} onShifts={()=>open('Shifts and Checklist')}/></>:view==='Applications and Credentials'?(selected==='Applications'?<ApplicantRecords onContestSelect={id=>{setContestEmployee(id);open('Evaluations and Incentives','Quarterly Excellence Contest')}}/>:<StaffingWorkspace key="credentials" office initialSection="Credential approval" visibleSections={["Credential approval"]}/>):view==='Evaluations and Incentives'?(selected==='Referral Program'?<ReferralProgram/>:selected==='Quarterly Excellence Contest'?<QuarterlyContest office employeeId={contestEmployee}/>:<EvaluationIncentive office/>):view==='Attendance & DNR'?(selected==='No Call, No Show'?<NoCallNoShow/>:<FeedbackWorkspace office/>):view==='Inactive Board'?<InactiveBoard/>:view==='Contracts'?<ContractAgreement office/>:view==='Branding & Connections'?(selected==='Brand Colors'?<BrandColors/>:selected==='Always Nursing Merch'?<MerchPortal office/>:selected==='Demo Access Links'?<DemoLinks/>:<Expansion mode={selected==='Connections'?'Connections':'Brand & distance'}/>):<><h2>{view}</h2><StaffingWorkspace key={view} office overview={view==='Overview'} visibleSections={view==='Shifts and Checklist'?['Shift setup']:view==='Message and Files'?['Employee messages','Payroll documents']:['Time records']} initialSection={view==='Message and Files'?'Employee messages':view==='Shifts and Checklist'?'Shift setup':'Time records'}/></>}
 <footer>Always Nursing Staffing Agency · Office Workspace</footer></main></div>
}
