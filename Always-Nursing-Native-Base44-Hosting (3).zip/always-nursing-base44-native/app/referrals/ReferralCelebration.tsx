'use client';
import {useEffect,useRef} from 'react';

/** Decorative celebration, played once when the referral panel enters view. */
export default function ReferralCelebration({continuous=false}:{continuous?:boolean}){
 const canvas=useRef<HTMLCanvasElement>(null);
 useEffect(()=>{
  const element=canvas.current,parent=element?.parentElement;
  if(!element||!parent)return;
  const context=element.getContext('2d'),motion=window.matchMedia('(prefers-reduced-motion: reduce)');
  if(!context||motion.matches)return;
  let frame=0,timer=0,played=false,started=0,previous=0,lastBurst=-600;
  const particles:{x:number;y:number;vx:number;vy:number;life:number;color:string}[]=[];
  function stop(){cancelAnimationFrame(frame);window.clearTimeout(timer);context!.clearRect(0,0,element!.width,element!.height)}
  function paint(now:number){
   if(!continuous&&now-started>=5000){stop();return}
   const dt=Math.min(2,(now-previous)/16.7);previous=now;
   context!.clearRect(0,0,element!.width,element!.height);
   if(now-started-lastBurst>=600&&(continuous||now-started<3800)){
    lastBurst=now-started;
    const x=element!.width*(.15+Math.random()*.7),y=element!.height*(.12+Math.random()*.65);
    for(let i=0;i<44;i++){const angle=i/44*Math.PI*2,speed=1.2+Math.random()*3;particles.push({x,y,vx:Math.cos(angle)*speed,vy:Math.sin(angle)*speed,life:1,color:(continuous?['#2469dc','#ffd66b','#cf303b']:['#b8860b','#e5b831','#ffd66b'])[i%3]})}
   }
   for(let i=particles.length-1;i>=0;i--){const p=particles[i];p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=.025*dt;p.life-=.013*dt;if(p.life<=0){particles.splice(i,1);continue}context!.globalAlpha=p.life*.85;context!.fillStyle=p.color;context!.beginPath();context!.arc(p.x,p.y,2.4,0,Math.PI*2);context!.fill()}
   context!.globalAlpha=1;frame=requestAnimationFrame(paint);
  }
  const observer=new IntersectionObserver(entries=>{
   if(played||!entries.some(e=>e.isIntersecting))return;
   played=true;observer.disconnect();
   element.width=Math.max(1,parent.clientWidth);element.height=Math.max(1,parent.clientHeight);
   started=previous=performance.now();frame=requestAnimationFrame(paint);if(!continuous)timer=window.setTimeout(stop,5000);
  },{threshold:0});
  const onMotionChange=()=>{if(motion.matches){observer.disconnect();stop()}};
  observer.observe(parent);motion.addEventListener('change',onMotionChange);
  return()=>{observer.disconnect();motion.removeEventListener('change',onMotionChange);stop()};
 },[continuous]);
 return <canvas ref={canvas} className="referral-fireworks" aria-hidden="true"/>;
}
